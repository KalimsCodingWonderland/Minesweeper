#ifndef GAME_WINDOW_H
#define GAME_WINDOW_H

void showGameWindow(const std::string &playerName);

#endif // GAME_WINDOW_H



