//
// Created by kalim on 7/28/2024.
//

#ifndef WELCOME_WINDOW_H
#define WELCOME_WINDOW_H

void showWelcomeWindow();

#endif // WELCOME_WINDOW_H



