#ifndef LEADERBOARD_H
#define LEADERBOARD_H

#include <SFML/Graphics.hpp>
#include <vector>
#include <string>

void showLeaderboardWindow(sf::RenderWindow &boomboomWindow, bool youWinz, int speedyGonzales, const std::string &playerDude, bool &isNapTime, sf::Sprite &freezeButton, sf::Texture &napTexture);

#endif // LEADERBOARD_H





