#include <iostream>
#include "WelcomeWindow.h"

int main() {
    showWelcomeWindow();
    return 0;
}
