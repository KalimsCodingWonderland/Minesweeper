1 Name: Kalim Qazi
2 Section: Daniel Melendez / Aiden Thomas
3 UFL email: kqazi@ufl.edu
4 System: x64-based PC
5 Compiler: g++
6 SFML version: GCC 7.3.0 MinGW (SEH) - 64-bit
7 IDE: CLion
8 Other notes: None